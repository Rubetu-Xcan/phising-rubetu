var buka = new Audio();
buka.src = "https://j.top4top.io/m_1992ngyc30.mp3";

var tutup = new Audio();
tutup.src = "https://j.top4top.io/m_1992ngyc30.mp3";